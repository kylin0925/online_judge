#include <stdio.h>
int main(int argc, char* argv[])
{
   int disks;
   char mov[250];
   int d1[120]={0},d2[120]={0},d3[120]={0};
   while(scanf("%d &s",&disks,&mov)==2)
   {
   }
        return 0;
}
 