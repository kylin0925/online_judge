#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[])
{
  int num1,num2,i,j,max_len;

  if(scanf("%d %d",&num1,&num2)==2)
  {
    max_len=0;

    for(i=num1;i<=num2;i++)
    {

    }
  }
  return 0;
}
 