#include <stdio.h>
#include <string.h>
int fir[10]={1,0,1,1,0,1,1,1,1,1};
int sec[20]={1,1,0,1,0,1,0,1,1,1,1,0,1,0,0,1,1,1,1,1};
int thi[10]={0,0,1,1,1,1,1,0,1,1};
int fou[20]={1,1,0,1,1,0,0,1,0,1,0,1,1,1,0,1,1,1,0,1};
int fiv[10]={1,0,1,1,0,1,1,0,1,1};
int main()
{
    int l,i,j,x,cnum;
    char num[15];
    while(scanf("%d %s",&l,&num)==2)
    {

    }
        return 0;
}

