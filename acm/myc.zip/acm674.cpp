#include <stdio.h>
int main()
{
     char a;
     int i=0;
        while(scanf("%c",&a)==1)
        {

              printf("%c",a[i]);
              i++;
        }
        return 0;
}
