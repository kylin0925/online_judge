#include <stdio.h>
int main(int argc, char* argv[])
{
       char   num[4]="1234";
       char   di[2]="ab";
       char   a;
       int    nlen=0,dlen=0;

       while(scanf("%c",a)==1)
       {
            if(isdigit(a)!=0)
            {
               num[len++]=a;
            }
            else if(is)

       }
        return 0;
}
 