#include <stdio.h>
#include <conio.h>
int main()
{
    sscanf();
        return 0;
}
 