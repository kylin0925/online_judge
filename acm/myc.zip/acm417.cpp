#include <stdio.h>
#include <string.h>
int main()
{
    char in[];
    long con;
    while(scanf("%s",&in)!=EOF)
    {
         con=0;
         for(i=0;i<strlen(in);i++)
         {

         }
        printf("%d\n",con);
    }
        return 0;
}
 